import InfiniteMenu from './infinitemenu';

const menu = new InfiniteMenu(document.querySelector('nav.menu'));