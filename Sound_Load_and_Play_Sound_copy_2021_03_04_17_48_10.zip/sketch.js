/*
 * @name Load and Play Sound
 * @description Load sound during preload(). Play a sound when canvas is clicked.
 * <br><br><em><span class="small"> To run this example locally, you will need the
 * <a href="http://p5js.org/reference/#/libraries/p5.sound">p5.sound library</a>
 * a sound file, and a running <a href="https://github.com/processing/p5.js/wiki/Local-server">local server</a>.</span></em>
 */
let song;
var x = 300;
var y = 200;
var d = 50;
var state = false;
let sentence = "PRESSHERE!";
let sentenceArray = [];
let r = 100;
let theta = 0;

function setup() {
  song = loadSound('assets/lucky_dragons_-_power_melody.mp3');
  createCanvas(2800, 500);
  background(0);
  sentenceArray = sentence.split(""); // splits a string into an array of chars

  print(sentenceArray);
}

function draw() {
  if (state) {
    background(0);
  } else {
    background(255);
  }
  translate(width / 2, height / 2);
  let x = r * cos(theta);
  let y = r * sin(theta);
  
  for (let i = 0; i < sentenceArray.length; i++) {
    rotate(QUARTER_PI / 1.25);
    text(sentenceArray[i], x, y);
}}



function mousePressed() {
  if (song.isPlaying(dist(mouseX, mouseY, x, y) < d/2)) {
    // .isPlaying() returns a boolean
    song.stop();
    state = !state;

  } else {
    song.play();
    state = !state;

  }
}
